:a
node index.js
goto:a
